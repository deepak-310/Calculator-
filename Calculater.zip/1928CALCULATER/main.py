# ALL header file
from tkinter import *
from tkinter.messagebox import *
import math as m
#FONT VARIABLE
font=('Arial Black',15)

# ALL BUTTON FUNTIONS
def clear():
    ex=textField.get()
    ex=ex[0:len(ex)-1]
    textField.delete(0,END)
    textField.insert(0,ex)

def all_clear():
    textField.delete(0,END)

def click_btn_funtion(event):
    b=event.widget
    text=b['text']
    

    if text=='x':
        textField.insert(END,"*")
        return;

    if text=='=':
        try:
            ex=textField.get()
            ans=eval(ex)
            textField.delete(0,END)
            textField.insert(0,ans)
        except Exception as e:
            print("Error..",e)
            showerror("Error..",e)


        return ;
    textField.insert(END,text)
window=Tk()
window.title('CALCULATOR')
window.geometry('400x440')

#picture label
pic=PhotoImage(file='image/cal1.png')
headingLabel=Label(window,image=pic)
headingLabel.pack(side=TOP)

#heading label
heading=Label(window,text='MYCALCULATOR',font=font)
heading.pack(side=TOP)

#textfiled
textField=Entry(window,font=font,justify=CENTER)
textField.pack(side=TOP,fill=X,padx=10)

#buttonsframe
buttonFrame=Frame(window)
buttonFrame.pack(side=TOP,pady=5)

#Adding Buttons1 to 9
temp=1
for i in range(0,3):
    for j in range(0,3):
        btn=Button(buttonFrame,text=str(temp),font=font,width=5,relief='ridge',activebackground='red',activeforeground='white')
        btn.grid(row=i,column=j,padx=5,pady=1)
        temp= temp+1
        btn.bind('<Button-1>',click_btn_funtion)
#zero button
zerobtn=Button(buttonFrame,text='0',font=font,width=5,relief='ridge',
               activebackground='red',activeforeground='white')
zerobtn.grid(row=3,column=0,padx=1,pady=1)

#Dot button
dotbtn=Button(buttonFrame,text='.',font=font,width=5,relief='ridge',
              activebackground='red',activeforeground='white')
dotbtn.grid(row=3,column=1,padx=1,pady=0)

#equal button
equalbtn=Button(buttonFrame,text='=',font=font,width=5,relief='ridge',
                activebackground='red',activeforeground='white')
equalbtn.grid(row=3,column=2,padx=1,pady=0)

#Pluse button
plusbtn=Button(buttonFrame,text='+',font=font,width=5,relief='ridge',
               activebackground='red',activeforeground='white')
plusbtn.grid(row=0,column=3,padx=1,pady=0)

#substract button
minusbtn=Button(buttonFrame,text='-',font=font,width=5,relief='ridge',
                activebackground='red',activeforeground='white')
minusbtn.grid(row=1,column=3,padx=1,pady=0)

#multipal button
mulbtn=Button(buttonFrame,text='x',font=font,width=5,relief='ridge',
              activebackground='red',activeforeground='white')
mulbtn.grid(row=2,column=3,padx=1,pady=0)

#divid Button
divbtn=Button(buttonFrame,text='/',font=font,width=5,relief='ridge',
              activebackground='red',activeforeground='white')
divbtn.grid(row=3,column=3,padx=1,pady=0)

#clear button
clearbtn=Button(buttonFrame,text='<--',font=font,width=13,relief='ridge',
                activebackground='red',activeforeground='white',command=clear)
clearbtn.grid(row=4,column=0,padx=1,pady=0,columnspan=2)

#all clear button
allClearbtn=Button(buttonFrame,text='AC',font=font,width=13,relief='ridge',
                   activebackground='red',activeforeground='white',command=all_clear)
allClearbtn.grid(row=4,column=2,padx=1,pady=0,columnspan=2)


#binding all buttons
plusbtn.bind('<Button-1>',click_btn_funtion)
minusbtn.bind('<Button-1>',click_btn_funtion)
mulbtn.bind('<Button-1>',click_btn_funtion)
divbtn.bind('<Button-1>',click_btn_funtion)
zerobtn.bind('<Button-1>',click_btn_funtion)
dotbtn.bind('<Button-1>',click_btn_funtion)
equalbtn.bind('<Button-1>',click_btn_funtion)



#####################################################################################################
#####################################################################################################




window.mainloop()


